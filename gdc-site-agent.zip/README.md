# GDC Agent-Mode Site

Simple starter for Vercel deployment.
